# Release Notes v0.4.1

The release fixes issue #7 LZMA2 reader. There has been a bug in the
LZMA2 reader.
