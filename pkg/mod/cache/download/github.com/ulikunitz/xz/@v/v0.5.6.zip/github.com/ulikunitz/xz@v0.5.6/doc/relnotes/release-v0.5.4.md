# Release Notes v0.5.4

The release fixes issue #15 related to an unexpeded padding size of 5.
The padding size test has now been removed.

Many thanks to Dórian C. Langbeck for reporting the issue.
