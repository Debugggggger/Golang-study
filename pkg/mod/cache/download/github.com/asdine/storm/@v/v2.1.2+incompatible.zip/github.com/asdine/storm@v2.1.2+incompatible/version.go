package storm

// Version of Storm
const Version = "2.0.0"
